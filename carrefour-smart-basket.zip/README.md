# Carrefour Smart Basket (Option A: Static)
Deployable on Vercel/Netlify as a static site. Upload *real* Carrefour price files (Price*.gz, optional Promo*.gz), the app parses them client-side and computes a basket with shipping.

## Quick start (local)
```bash
npm i
npm run dev
```

## Build
```bash
npm run build
```
Output goes to `dist/`.

## Deploy on Vercel
- Create a new project, import this repo.
- Framework: **Other** (or Vite).
- Build command: `npm run build`
- Output directory: `dist`
