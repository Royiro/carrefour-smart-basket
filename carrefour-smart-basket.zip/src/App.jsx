import React, { useMemo, useRef, useState } from 'react'
import Papa from 'papaparse'
import { unzipSync, strFromU8 } from 'fflate'

const NIS = (n) => new Intl.NumberFormat('he-IL',{style:'currency',currency:'ILS',maximumFractionDigits:2}).format(n)

function detectDelimiter(sample){
  if (sample.includes('|')) return '|'
  if (sample.includes('\t')) return '\t'
  return ','
}
function normalizeHeb(s){
  return (s||'').toLowerCase().replace(/["'`]/g,'').replace(/[()\[\]]/g,' ').replace(/\s+/g,' ').trim()
}
function keywordScore(needle, haystack){
  const n = normalizeHeb(needle); const h = normalizeHeb(haystack||'')
  const tokens = n.split(' ').filter(Boolean)
  let score = 0
  for (const t of tokens) if (h.includes(t)) score += 1
  return score / Math.max(tokens.length,1)
}
function arrayBufferToString(ab){
  const u8 = new Uint8Array(ab)
  try {
    const unzipped = unzipSync({ 'file': u8 })
    const first = Object.values(unzipped)[0]
    return strFromU8(first)
  } catch {
    try {
      const gunzipped = unzipSync({ 'file.gz': u8 })
      const first = Object.values(gunzipped)[0]
      return strFromU8(first)
    } catch {
      return new TextDecoder('utf-8').decode(u8)
    }
  }
}
function parseCsv(text){
  const delimiter = detectDelimiter(text.slice(0,512))
  const { data } = Papa.parse(text,{ header:true, delimiter, skipEmptyLines:true })
  return data
}
function toCatalog(rows){
  const codeKeys = ['itemcode','item_code','barcode','itemcode\u200f','item_code\u200f','מקט','ברקוד']
  const nameKeys = ['itemname','item_name','name','itemname\u200f','שם_מוצר','תיאור_מוצר']
  const priceKeys = ['price','itemprice','unit_price','price\u200f','מחיר']
  const sizeKeys = ['unit_qty','unit_of_measure','size','אריזה','כמות']

  const out = []
  for (const r of rows){
    const get = (keys)=>{
      for (const k of keys){
        const v = r[k] ?? r[k?.toLowerCase?.()] ?? r[k?.toUpperCase?.()]
        if (v!==undefined && v!==null && String(v).length>0) return v
      }
      return undefined
    }
    const code = String(get(codeKeys)||'').trim()
    const name = String(get(nameKeys)||'').trim()
    const rawPrice = get(priceKeys)
    const size = String(get(sizeKeys)||'').trim()
    if (!name) continue
    const price = Number(String(rawPrice).replace(/[^0-9.]/g,''))
    if (!isFinite(price)) continue
    out.push({ code, name, price, size })
  }
  const byKey = new Map()
  for (const c of out){
    const k = c.code || c.name
    const prev = byKey.get(k)
    if (!prev || c.price < prev.price) byKey.set(k,c)
  }
  return Array.from(byKey.values())
}
function matchItems(userLines, catalog){
  return userLines.map((raw)=>{
    const line = raw.trim()
    if (!line) return { requested: raw, matchedName: '', price: 0 }
    let best = null, bestScore = 0
    for (const c of catalog){
      const s = keywordScore(line, c.name)
      if (s>bestScore || (s===bestScore && best && c.price<best.price)){ best=c; bestScore=s }
    }
    if (!best || bestScore<0.4) return { requested: line, matchedName: '(לא נמצאה התאמה מספקת)', price: 0 }
    return { requested: line, matchedName: best.name, code: best.code, price: best.price }
  })
}
function downloadCsv(filename, rows){
  const csv = Papa.unparse(rows)
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' })
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url; a.download = filename; document.body.appendChild(a); a.click()
  document.body.removeChild(a); URL.revokeObjectURL(url)
}

export default function App(){
  const [list, setList] = useState('אורז בסמתי\nשימורי גרגירי חומוס\nטופו 1.2קילו\nדנונה פרו 1.5%\nערמונים קלויים\nמשקה סויה אלטרנטיב\nכוסמת\nעדשים ירוקות\nעדשים שחורות\nרסק עגבניות')
  const [shipping, setShipping] = useState(30)
  const [loading, setLoading] = useState(false)
  const [catalog, setCatalog] = useState([])
  const [alloc, setAlloc] = useState(null)
  const [errors, setErrors] = useState([])
  const fileRef = useRef(null)

  const totalProducts = useMemo(()=> alloc ? alloc.reduce((s,r)=>s+(r.price||0),0) : 0, [alloc])
  const grand = useMemo(()=> totalProducts + ((alloc && alloc.some(r=>r.price>0)) ? shipping : 0), [alloc, shipping, totalProducts])

  async function handleFiles(files){
    if (!files || files.length===0) return
    setLoading(true); setErrors([])
    const allRows = []
    for (const file of Array.from(files)){
      try{
        const buf = await file.arrayBuffer()
        const text = arrayBufferToString(buf)
        const rows = parseCsv(text)
        allRows.push(...rows)
      } catch(e){
        setErrors(p=>[...p, `שגיאה בקריאת הקובץ ${file.name}: ${e?.message||e}`])
      }
    }
    const cat = toCatalog(allRows); setCatalog(cat)
    const lines = list.split('\n').map(s=>s.trim()).filter(Boolean)
    const match = matchItems(lines, cat); setAlloc(match); setLoading(false)
  }
  function onExport(){
    if (!alloc) return
    const rows = alloc.map(a=>({ 'פריט מבוקש': a.requested, 'התאמה': a.matchedName, 'ברקוד': a.code||'', 'מחיר': a.price }))
    rows.push({ 'פריט מבוקש':'—','התאמה':'—','ברקוד':'—','מחיר':'—' })
    rows.push({ 'פריט מבוקש':'סכום פריטים','התאמה':'','ברקוד':'','מחיר': totalProducts })
    rows.push({ 'פריט מבוקש':'משלוח','התאמה':'','ברקוד':'','מחיר': alloc.some(r=>r.price>0)? shipping : 0 })
    rows.push({ 'פריט מבוקש':'סה"כ','התאמה':'','ברקוד':'','מחיר': grand })
    downloadCsv(`carrefour_allocation_${Date.now()}.csv`, rows)
  }

  return (
    <div className="container">
      <h1>🛒 Carrefour Smart Basket — נתוני אמת דרך קבצים</h1>
      <div className="card">
        <div className="row">
          <div>
            <label>רשימת קניות (שורה לכל פריט)</label>
            <textarea value={list} onChange={(e)=>setList(e.target.value)} />
            <div className="spacer"></div>
            <label>משלוח (₪)</label>
            <div><input type="number" value={shipping} onChange={(e)=>setShipping(Number(e.target.value||0))} style={{width:'120px'}} /></div>
          </div>
          <div>
            <label>העלה קובצי Carrefour (Price*.gz, Promo*.gz לא חובה)</label>
            <div className="spacer"></div>
            <input ref={fileRef} type="file" multiple accept=".gz,.csv,.zip" onChange={(e)=>handleFiles(e.target.files)} />
            <div className="spacer"></div>
            <button className="btn" onClick={()=>handleFiles(fileRef.current?.files||null)} disabled={loading || !fileRef.current?.files?.length}>חשב סל</button>
            <span style={{marginInlineStart:'8px'}}></span>
            <button className="btn outline" onClick={onExport} disabled={!alloc || !alloc.length}>יצוא CSV</button>
            <div className="spacer"></div>
            {loading ? <div className="muted">טוען ומפרש קבצים…</div> : null}
            {!!catalog.length && <div className="muted">נטענו {catalog.length.toLocaleString()} מוצרים לקטלוג</div>}
          </div>
        </div>
        {errors.length>0 && <div style={{color:'#b91c1c', marginTop:8}}>{errors.map((e,i)=>(<div key={i}>• {e}</div>))}</div>}
        <div className="spacer"></div>
        <span className="badge">חנות: Carrefour</span>
        <span className="badge">תמחור: לפי הקובץ האחרון שהועלה</span>
        <span className="badge">משלוח: {NIS(shipping)}</span>
      </div>

      {alloc && (
        <div className="card">
          <div className="grid-head">
            <div>פריט מבוקש</div>
            <div>התאמה מקטלוג Carrefour</div>
            <div className="right">מחיר</div>
          </div>
          <div className="spacer"></div>
          {alloc.map((r, idx)=>(
            <div key={idx} className="grid-row">
              <div>{r.requested}</div>
              <div className="muted">{r.matchedName} {r.code? <small className="muted">({r.code})</small> : null}</div>
              <div className="right"><b>{r.price ? NIS(r.price) : '—'}</b></div>
            </div>
          ))}
          <div className="spacer"></div>
          <div className="grid-row" style={{border:'none', background:'transparent'}}>
            <div></div><div className="right muted">סכום פריטים</div><div className="right"><b>{NIS(totalProducts)}</b></div>
          </div>
          <div className="grid-row" style={{border:'none', background:'transparent'}}>
            <div></div><div className="right muted">משלוח</div><div className="right"><b>{alloc.some(r=>r.price>0)? NIS(shipping) : NIS(0)}</b></div>
          </div>
          <div className="grid-row" style={{border:'none', background:'transparent'}}>
            <div></div><div className="right">סה"כ</div><div className="right" style={{fontSize:'1.1rem'}}><b>{NIS(grand)}</b></div>
          </div>
        </div>
      )}

      <div className="card muted" style={{fontSize:'.9rem'}}>
        <div><b>איך עובדים עם נתוני אמת של קרפור?</b></div>
        <ul>
          <li>הורידו את קובצי <code>Price*.gz</code> מהפורטל של קרפור (ואופציונלית <code>Promo*.gz</code>).</li>
          <li>העלו אותם כאן — האפליקציה תפתח, תפרסר ותחשב סל.</li>
          <li>אפשר לשנות סכום משלוח, ולייצא את התוצאה ל‑CSV.</li>
        </ul>
      </div>
    </div>
  )
}
